import { NextResponse } from 'next/server';
import { checkEmailsForInterviews } from '@/actions/cron/cron.action'; // Apnar main Server Action

export async function GET(request: Request) {
  // Security verification: jeno bairer keu automatic eta hit kore apnar API quota sesh na korte pare
  const authHeader = request.headers.get('authorization');
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return new Response('Unauthorized', { status: 401 });
  }

  try {
    // Apnar Server Action ke call korche background execution er jonno
    await checkEmailsForInterviews();
    return NextResponse.json({
      success: true,
      message: 'Cron job executed successfully',
    });
  } catch (error) {
    console.error('Cron Action processing failed:', error);
    return NextResponse.json(
      { success: false, error: 'Internal Server Error' },
      { status: 500 }
    );
  }
}
