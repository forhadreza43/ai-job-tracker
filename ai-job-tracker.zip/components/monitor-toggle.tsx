'use client';

import { useState, useTransition } from 'react';
import { toggleAiMonitoring } from '@/actions/cron/userSetting.action';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner'; // অথবা আপনার ব্যবহৃত নোটিফিকেশন লাইব্রেরি

interface AiToggleProps {
  initialStatus: boolean;
  lastChecked: Date | null;
}

export function AiMonitoringToggle({
  initialStatus,
  lastChecked,
}: AiToggleProps) {
  const [isPending, startTransition] = useTransition();
  const [isActive, setIsActive] = useState(initialStatus);

  const handleToggle = (checked: boolean) => {
    // অপটিমিস্টিকালি UI আগে চেঞ্জ করে নেওয়া
    setIsActive(checked);

    startTransition(async () => {
      const result = await toggleAiMonitoring(checked);

      if (!result.success) {
        // ফেইল করলে আগের স্টেটে ফেরত যাওয়া
        setIsActive(!checked);
        toast.error(result.error || 'Something went wrong');
      } else {
        toast.success(result.message);
      }
    });
  };

  return (
    <div className="p-4 border rounded-lg bg-card text-card-foreground shadow-sm">
        <Switch
          checked={isActive}
          disabled={isPending}
          onCheckedChange={handleToggle}
        />
      {/* {isActive && lastChecked && (
        <p className="text-xs text-muted-foreground mt-2">
          Last scanned at: {new Date(lastChecked).toLocaleString()}
        </p>
      )} */}
    </div>
  );
}
